package com.example.utspweb;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class RegistrationFragment extends Fragment {
    private Spinner spinner2, spinner3, spinner4, spinner5;
    private ArrayAdapter<String> spinnerAdapter;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public static RegistrationFragment newInstance(String param1, String param2) {
        RegistrationFragment fragment = new RegistrationFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public RegistrationFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_registration, container, false);
        spinner2 = view.findViewById(R.id.spinner2);
        spinner3 = view.findViewById(R.id.spinner3);
        spinner4 = view.findViewById(R.id.spinner4);
        spinner5 = view.findViewById(R.id.spinner5);

        spinnerAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        populateSpinner(spinner2, "Iwan Iskandar, S.T., M.T.", "Reski Mai Candra, S.T., M.Sc.", "Muhammad Affandes, S.T., M.T.", "Fadhilah Syafria, S.T., M.Kom");
        populateSpinner(spinner3, "Iwan Iskandar, S.T., M.T.", "Reski Mai Candra, S.T., M.Sc.", "Muhammad Affandes, S.T., M.T.", "Fadhilah Syafria, S.T., M.Kom");
        populateSpinner(spinner4, "Iwan Iskandar, S.T., M.T.", "Reski Mai Candra, S.T., M.Sc.", "Muhammad Affandes, S.T., M.T.", "Fadhilah Syafria, S.T., M.Kom");
        populateSpinner(spinner5, "Iwan Iskandar, S.T., M.T.", "Reski Mai Candra, S.T., M.Sc.", "Muhammad Affandes, S.T., M.T.", "Fadhilah Syafria, S.T., M.Kom");

        return view;
    }

    private void populateSpinner(Spinner spinner, String item1, String item2, String item3, String item4) {
        spinnerAdapter.clear();

        if (!isEmptyItemInOtherSpinners(spinner)) {
            spinnerAdapter.add(item1);
        }
        if (!isItemInOtherSpinners(spinner, item2)) {
            spinnerAdapter.add(item2);
        }
        if (!isItemInOtherSpinners(spinner, item3)) {
            spinnerAdapter.add(item3);
        } if (!isItemInOtherSpinners(spinner, item4)) {
            spinnerAdapter.add(item4);
        }

        spinner.setAdapter(spinnerAdapter);
    }
    private boolean isEmptyItemInOtherSpinners(Spinner spinner) {
        for (Spinner otherSpinner : new Spinner[]{spinner2, spinner3, spinner4, spinner5}) {
            if (!otherSpinner.equals(spinner) && otherSpinner.getSelectedItem() != null) {
                String selectedItem = otherSpinner.getSelectedItem().toString();
                if (selectedItem.equals("Select Item")) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isItemInOtherSpinners(Spinner spinner, String item) {
        for (Spinner otherSpinner : new Spinner[]{spinner2, spinner3, spinner4, spinner5}) {
            if (!otherSpinner.equals(spinner) && otherSpinner.getSelectedItem() != null) {
                String selectedItem = otherSpinner.getSelectedItem().toString();
                if (selectedItem.equals(item)) {
                    return true;
                }
            }
        }
        return false;
    }


}
